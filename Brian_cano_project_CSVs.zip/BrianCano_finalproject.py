#BRIAN CANO 
#handy commands:  pip install sklearn  #pip install pandas  #  reset -f    

#------------  Required for project -----------------------
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
from scipy import stats
#------------  end requirements  -----------------------

import pandas as pd 
import pylab as plb
import os 
#did not execute:  import statsmodels as sm    /   import scipy as sp
from sklearn.linear_model import LinearRegression
    # Why this method?  "This is the quintessential method used by majority of machine learning engineers and data scientists." SOURCE:  https://medium.freecodecamp.org/data-science-with-python-8-ways-to-do-linear-regression-and-measure-their-speed-b5577d75f8b
import statsmodels.api as sm
from statsmodels.formula.api import ols #ordinary least squares model.

# parameter initialization ----------------------------
fy = 2010  #default years
fe = 2016 
r_square_score = [] #define outside the function so I get output 

default_switch = input("Analysis of baseball salaries and wins.  Use defaults? [y/n]: ") 

while True:
    try:
        if default_switch in ('y', 'Y'):
            print("Using defaults.") 
            break
        elif default_switch in ('n', 'N'):
            while True:
                try:
                    fy = int(input("Enter beginning year (>=1990, <=2016): "))
                    if fy < 1990 or fy > 2016:
                        raise ValueError #back to the print message/input  
                    break
                except ValueError:
                    print("Invalid beginning year.")
            while True:
                try:
                    fe = int(input("Enter end year (>= beginning year, <=2016): "))
                    if fe < fy or fe > 2016:
                        raise ValueError #back to the print message/input  
                    break
                except ValueError:
                    print("Invalid end year.")
        else:
            print("invalid input, using defaults.") 
            break  #without this break, it is an infinite loop 
        break
    except:
        break
        
firstyear = fy
endyear = fe 

#define relative path for source files ----------------------------
dir = os.path.dirname(__file__)
team_filename = os.path.join(dir, 'baseballdatabank_2017','Teams.csv')
salaries_filename = os.path.join(dir, 'baseballdatabank_2017','Salaries_ed.csv')

#put CSV into a pandas dataframe 
#teams = pd.read_csv('baseballdatabank_2017\Teams.csv')  -- not "universal" code across all OS 
teams = pd.read_csv(team_filename)
#this address has to be local to the current directory not 'C;\ ... etc.' 
#although a dataframe, the index just reads like this:
    #In[xx]:  index = teams.index
    #Out[xx]:  RangeIndex(start=0, stop=2835, step=1)
teams = teams[teams['yearID'] >= 1990]  #subset of the original data 
teams = teams[['yearID', 'teamID', 'Rank', 'R', 'RA', 'G', 'W', 'H', 'BB', 'HBP', 'AB', 'SF', 'HR', '2B', '3B']]
#drop unwanted columns, leaving only a index as year/team, and one column for salary
#drop in-game stats, etc. but keep Wins 'W'  
teams.drop(['Rank', 'R', 'RA', 'G', 'H', 'BB', 'HBP', 'AB', 'SF', 'HR', '2B', '3B'], axis=1, inplace=True)
#teams.shape shows 3 columns:  yearID teamID and W 

#set index.   to drop indexes and reset them, use teams.reset_index#
teams = teams.set_index(['yearID', 'teamID'], verify_integrity=True)
    #teams.shape now shows just 1 column (W) 
    #this is a unique index :
    #teams.index.is_unique #returns True 
    #In[xx]:  index = teams.index
    #output is a MultiIndex showing levels as the values of names=['yearID', 'teamID'])

    #teams.head(5) -- output is only 1 column, with each row indexed by year/team as an identifier
#import salaries
salaries = pd.read_csv(salaries_filename)
    #salaries by Year and Team 
salaries_by_yearID_teamID = salaries.groupby(['yearID', 'teamID'])['salary'].sum()
    #salaries_by_yearID_teamID.shape yilds: (918, ) which is the length in one dimension  
    #salaries_by_yearID_teamID[2001, 'LAN'] -- show the sum for one team, one year. 

teams = teams.join(salaries_by_yearID_teamID)

#teamIDs not consistent across tables be aware 
    #salaries_by_yearID_teamID[2010, 'WAS']  #Washington Nationals 
    #salaries_by_yearID_teamID[2016, 'WAS']  #no result! 
    #salaries_by_yearID_teamID[2016, 'WSN']  #results.  ... standarized Salaries externally 

#remove the NaNs before placing into a matrix 
#filtered_data = raw_data[~np.isnan(raw_data["column_name_with_the_nans"])]
    #if no tilde, then the method KEEPS the NaNs and tosses the values
teams = teams[~np.isnan(teams["salary"])]

def millions(x, pos):  #x is value, pos is tick position 
    return '$%1.f' % (x*1e-6)  #string formatting; multiply x * 0.000001.  $1.1fM would put an M @ end

formatter = FuncFormatter(millions)

def plot_salary_wins(teams, year):    
    teams_year = teams.xs(year)  #xs gives a section of rows or columns; e.g. teams.xs(2010)
    #establish linear regression line for that year 
    team_mx = np.matrix(teams_year)
    x, y = team_mx[:, 1], team_mx[:, 0] #columns 0 (Wins) and 1 (Salary), colon for all rows
    mdl = LinearRegression().fit(x,y)   #model is built using scikit-learn 
    #plt.plot(x, mdl.predict(x),color='k') 
    fig, ax = plb.subplots()  #method returns a figure and axes object 
    #if plt.subplot were to be placed here, then error:  unhashable type: 'matrix'
    for i in teams_year.index:
        maxwins = teams_year.max()
        if i == 'LAN':  #Dodgers; commonly abbreviated as "LAD" 
            ax.scatter(teams_year['salary'][i], teams_year['W'][i], color="#1E90FF", s=200) 
            #hex value of Dodger Blue at  http://www.color-hex.com/color/1e90ff
            #s = 200 is pixels 
            #specifying 200 pixels diameter per mark 
            ax.annotate("LAD", (teams_year['salary'][i], teams_year['W'][i]),
                        bbox=dict(boxstyle="round", color="#1E90FF"),
                        xytext=(-30, 30), textcoords='offset points',
                        arrowprops=dict(arrowstyle="->", connectionstyle="angle,angleA=0,angleB=90,rad=10"))
        elif i == 'SFN':  #Giants; commonly abbreviated as "SF" 
            ax.scatter(teams_year['salary'][i], teams_year['W'][i], color="#FA4616", s=200)  
            ax.annotate("SF", (teams_year['salary'][i], teams_year['W'][i]),
                        bbox=dict(boxstyle="round", color="#FA4616"),
                        xytext=(30, -30), textcoords='offset points',
                        arrowprops=dict(arrowstyle="->", connectionstyle="angle,angleA=0,angleB=135,rad=10"))
        else:
            if teams_year['W'][i] == maxwins['W']:
                ax.scatter(teams_year['salary'][i], teams_year['W'][i], color="#FFEF00", s=200) 
                #color the maximum win team as yellow 
                ax.annotate(i, (teams_year['salary'][i], teams_year['W'][i]),
                        bbox=dict(boxstyle="round", color="#FFEF00"),
                        xytext=(-30, -30), textcoords='offset points',  #in order to keep it in the plot box
                        arrowprops=dict(arrowstyle="->", connectionstyle="angle,angleA=0,angleB=90,rad=10"))
            else:    
                ax.scatter(teams_year['salary'][i], teams_year['W'][i], color="grey", s=200)
    r_square_score.append(mdl.score(x,y)) #goodness of fit; R-square score; must be placed before plot and ax
        #r_square_score will be zipped below with another list
    plt.plot(x, mdl.predict(x),color='k', label = "regression") #label, in case of legend 
        #plots x vs predictions as a function of x.  
        #syntax for printing predictions list:  print(len(mdl.predict(x)))  /which = the number of datapoints
        #syntax for printing first 5 elements:  print((mdl.predict(x)[0:5])
    ax.xaxis.set_major_formatter(formatter) #set the x-axis to the "formatter" format 
    ax.tick_params(axis='x', labelsize=12)
    ax.tick_params(axis='y', labelsize=12)
    ax.set_title('Team Salaries vs Wins: '+ str(year), fontsize=18, fontweight='bold')
    ax.set_xlabel('Salaries ($MM)', fontsize=12)
    ax.set_ylabel('Regular Season Wins' , fontsize=12)
    #plt.legend(loc = "lower right")   -- i decided not to post the legend 
    plb.show()

#show the plots:  print the entire batch 
years_list = [] 
for j in range(firstyear, endyear+1): #last year is exclusionary! 
    plot_salary_wins(teams, j)
    years_list.append(j) 

#create a list of R-square results by year :  expression of fit (1 = perfect, 0 = no fit) 
r = list(zip(years_list,r_square_score))
print("R-square results by year: \n", r)

#requirements of project:  use scipy, so here is a regression plot using scipy 
teams_yrs_of_interest = teams.loc[firstyear:endyear+1]   #subset of the original data: select a range of rows
team_mx_yoi = np.matrix(teams_yrs_of_interest) #convert DataFrame to Matrix 
x1, y1 = teams_yrs_of_interest['salary'], teams_yrs_of_interest['W']  
slope, intercept, r_value, p_value, std_err = stats.linregress(x1, y1)
line = slope *x1 + intercept 

def plot_overall(teams_yrs_of_interest, firstyear, endyear): 
    fig, ax = plb.subplots()
    plt.plot(x1, line)
    ax.scatter(teams_yrs_of_interest['salary'], teams_yrs_of_interest['W'], color="grey", s=200)
    #repeat the plotting code
    ax.xaxis.set_major_formatter(formatter) #set the x-axis to the "formatter" format 
    ax.tick_params(axis='x', labelsize=12)
    ax.tick_params(axis='y', labelsize=12)
    ax.set_title('Team Salaries vs Wins '+ str(firstyear) + ' to ' + str(endyear), fontsize=12, fontweight='bold')
    ax.set_xlabel('Salaries ($MM)', fontsize=12)
    ax.set_ylabel('Regular Season Wins' , fontsize=12)  
    plb.show()
    
plot_overall(teams_yrs_of_interest, firstyear, endyear)  #output

def plot_influence(teams, firstyear):
    fig, ax = plb.subplots()
    teams_year = teams.xs(firstyear) 
    model_ols = ols("W ~ salary", data=teams_year).fit()
    fig = sm.graphics.influence_plot(model_ols, criterion="cooks")
    plb.show()

plot_influence(teams, firstyear) #output.  also creates a throwaway blank plot 

#  useful links and guides: ----------------------------
#syntax for pandas:  teams.loc[[firstyear:endyear, ['W', 'salary']] would work, selecting the two available columns explicitly, but this is redundant 
#tutorial https://www.shanelynn.ie/select-pandas-dataframe-rows-and-columns-using-iloc-loc-and-ix/
#also see https://pandas.pydata.org/pandas-docs/stable/indexing.html
#https://plot.ly/matplotlib/linear-fits/

 
    
    
    
    

